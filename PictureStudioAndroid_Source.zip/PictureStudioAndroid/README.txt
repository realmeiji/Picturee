PICTURE STUDIO ANDROID 1.0 — SOURCE PROJECT

This is a native Android WebView app with a Java MediaStore bridge.
It is not a website-only page. It queries Android MediaStore for image
buckets (album names), keeps distinct bucket IDs even when names repeat,
and copies a chosen image into selected album paths through MediaStore.

BUILD REQUIREMENTS
- AndroidIDE or Android Studio with Android SDK platform 35
- JDK 17
- Internet for the first Gradle dependency download

BUILD
1. Extract this ZIP.
2. Open the extracted PictureStudio folder as a project in AndroidIDE.
3. Allow Gradle sync/downloads.
4. Build > Assemble/Build APK.
5. Install the generated debug APK.
6. Open Picture Studio and grant photo access.
7. Choose an image, load albums, select albums, then copy.

IMPORTANT
- Android's document picker may show a system picker or a file-provider UI;
  it cannot force TECNO AI Gallery's own private screen to open.
- Album discovery uses MediaStore BUCKET_DISPLAY_NAME, BUCKET_ID and
  RELATIVE_PATH. This is Android's indexed media grouping, not a private
  TECNO Gallery database API. Hidden/unindexed content may be absent.
- Copying uses MediaStore insertion into each album's indexed relative path.
- Test with one image and one album first.
