package com.picturestudio.app;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.LinkedHashMap;
import java.util.Map;

public class MainActivity extends Activity {
    private static final int REQ_PERMISSION = 10;
    private static final int REQ_IMAGE = 11;
    private WebView web;
    private Uri selectedImage;
    private String selectedName = "selected-image";
    private final Map<String, Album> albums = new LinkedHashMap<>();

    static class Album {
        String id, name, relativePath;
        int count;
        Album(String i, String n, String p) { id=i; name=n; relativePath=p; count=0; }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "Android");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    private boolean hasImagePermission() {
        if (Build.VERSION.SDK_INT >= 33)
            return checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED;
        return checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    private void askPermission() {
        if (Build.VERSION.SDK_INT >= 33)
            requestPermissions(new String[]{Manifest.permission.READ_MEDIA_IMAGES}, REQ_PERMISSION);
        else
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQ_PERMISSION);
    }

    private void js(String script) {
        runOnUiThread(() -> web.evaluateJavascript(script, null));
    }

    private String quote(String s) {
        return JSONObject.quote(s == null ? "" : s);
    }

    private void openImagePicker() {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/*");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivityForResult(i, REQ_IMAGE);
    }

    @Override public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_IMAGE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            selectedImage = data.getData();
            try {
                Cursor c = getContentResolver().query(selectedImage,
                    new String[]{MediaStore.MediaColumns.DISPLAY_NAME}, null, null, null);
                if (c != null) {
                    if (c.moveToFirst()) selectedName = c.getString(0);
                    c.close();
                }
                // Keep the temporary read grant returned by the picker for this session.
            } catch (Exception ignored) {}
            js("window.onNativeImage(" + quote(selectedName) + ")");
        } else if (requestCode == REQ_IMAGE) {
            js("window.onNativeImageCancelled()");
        }
    }

    private JSONArray loadAlbums() throws Exception {
        albums.clear();
        Uri uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        String[] projection = {
            MediaStore.Images.Media.BUCKET_ID,
            MediaStore.Images.Media.BUCKET_DISPLAY_NAME,
            MediaStore.MediaColumns.RELATIVE_PATH
        };
        try (Cursor c = getContentResolver().query(uri, projection, null, null,
                MediaStore.MediaColumns.DATE_ADDED + " DESC")) {
            if (c != null) {
                int idCol=c.getColumnIndex(MediaStore.Images.Media.BUCKET_ID);
                int nameCol=c.getColumnIndex(MediaStore.Images.Media.BUCKET_DISPLAY_NAME);
                int pathCol=c.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH);
                while (c.moveToNext()) {
                    String id=c.getString(idCol);
                    String name=c.getString(nameCol);
                    String path=c.getString(pathCol);
                    if (id == null || path == null) continue;
                    Album a=albums.get(id);
                    if (a == null) { a=new Album(id, name == null ? "Unnamed album" : name, path); albums.put(id,a); }
                    a.count++;
                }
            }
        }
        JSONArray out=new JSONArray();
        for (Album a: albums.values()) {
            JSONObject o=new JSONObject();
            o.put("id",a.id); o.put("name",a.name); o.put("path",a.relativePath); o.put("count",a.count);
            out.put(o);
        }
        return out;
    }

    private String copyToAlbum(Album album) throws Exception {
        String mime=getContentResolver().getType(selectedImage);
        if (mime == null) mime="image/jpeg";
        String ext=".jpg";
        int dot=selectedName.lastIndexOf('.');
        if (dot>=0) ext=selectedName.substring(dot);
        String base=dot>=0?selectedName.substring(0,dot):selectedName;
        String display=selectedName;
        Uri collection=MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
        Uri created=null;
        for (int n=0;n<100;n++) {
            ContentValues v=new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, display);
            v.put(MediaStore.MediaColumns.MIME_TYPE,mime);
            v.put(MediaStore.MediaColumns.RELATIVE_PATH,album.relativePath);
            v.put(MediaStore.MediaColumns.IS_PENDING,1);
            created=getContentResolver().insert(collection,v);
            if (created != null) break;
            display=base+"_"+(n+1)+ext;
        }
        if (created==null) throw new Exception("Could not create image in "+album.name);
        try (InputStream in=getContentResolver().openInputStream(selectedImage);
             OutputStream out=getContentResolver().openOutputStream(created,"w")) {
            if (in==null || out==null) throw new Exception("Could not open image streams");
            byte[] buffer=new byte[65536]; int len;
            while ((len=in.read(buffer))>0) out.write(buffer,0,len);
        } catch (Exception e) {
            getContentResolver().delete(created,null,null);
            throw e;
        }
        ContentValues done=new ContentValues();
        done.put(MediaStore.MediaColumns.IS_PENDING,0);
        getContentResolver().update(created,done,null,null);
        return album.name;
    }

    public class Bridge {
        @JavascriptInterface public void requestPermission() {
            runOnUiThread(() -> {
                if (hasImagePermission()) js("window.onPermission(true)");
                else askPermission();
            });
        }
        @JavascriptInterface public void pickImage() {
            runOnUiThread(() -> openImagePicker());
        }
        @JavascriptInterface public String getAlbums() {
            try {
                if (!hasImagePermission()) return "{\"error\":\"permission\"}";
                return loadAlbums().toString();
            } catch (Exception e) { return "{\"error\":"+quote(e.getMessage())+"}"; }
        }
        @JavascriptInterface public String copy(String idsJson) {
            try {
                if (selectedImage==null) return "{\"error\":\"Choose an image first.\"}";
                JSONArray ids=new JSONArray(idsJson);
                int ok=0; JSONArray failed=new JSONArray();
                for (int i=0;i<ids.length();i++) {
                    String id=ids.getString(i);
                    Album a=albums.get(id);
                    if (a==null) { failed.put("Unknown album"); continue; }
                    try { copyToAlbum(a); ok++; }
                    catch(Exception e) { failed.put(a.name+": "+e.getMessage()); }
                }
                JSONObject result=new JSONObject();
                result.put("success",ok); result.put("failed",failed);
                return result.toString();
            } catch(Exception e) { return "{\"error\":"+quote(e.getMessage())+"}"; }
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode,permissions,results);
        if (requestCode==REQ_PERMISSION) {
            boolean granted=results.length>0 && results[0]==PackageManager.PERMISSION_GRANTED;
            js("window.onPermission("+granted+")");
        }
    }
}
